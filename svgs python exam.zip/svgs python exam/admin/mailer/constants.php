<?php
define('PASSWORD','padelkarS123'); // your password
<?php
require 'PHPMailer/PHPMailerAutoload.php';
require'constants.php';

//mail send sample code
$mail = new PHPMailer();
//$mail->SMTPDebug = 3;
$mail->isSMTP();
$mail->SMTPAuth =true;
$mail->SMTPSecure='tls';  //tls ssl
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;    // 587 465
$mail->IsHTML(true);
$mail->CharSet='UTF-8';
$mail->Username='padelkarshweta73@gmail.com';
$mail->Password=PASSWORD;
$mail->SetFrom('padelkarshweta73@gmail.com', 'vishal');
$mail->AddAddress('vicky141192@gmail.com','svgs');
$mail->addReplyTo('no-reply@gmail.com', 'No-reply');
$mail->addCC('kamblevishal007@gmail.com');
$mail->addAttachment('byby.png');   
$mail->Subject = 'Test Mail example';
$mail->Body="This is my sample mail";
$mail->SMTPOptions = array(
    'ssl' => [
        'verify_peer' => false,
        'verify_depth' => false,
        'allow_self_signed' => false,
        'verify_peer_name' => false
    ]
);

if (!$mail->send()) {
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message sent!';
}

?>
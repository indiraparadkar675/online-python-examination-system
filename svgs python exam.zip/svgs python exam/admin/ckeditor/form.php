<html>
<head>
    <style>
	body{
	margin:2%;
}
        .frm{
            margin:auto;
            width:60vw;
        }
        .btn{
	margin-left:20vw;
    margin-top:10px;
	width:100px;
	height:30px;
    background-color: blue;
	padding:2px 2px;
 color:white;
  border-radius:20px;
 
}
.btn-login{
	margin-right:30px;
    background-color: blue;
	padding:5px 20px;
	color:white;
	text-decoration:none;
	height:15px;
	float:right;
	border-radius:20px;
	font-size:13px;
}
       
        </style>
</head>
    <body>
	<h2>Admin Panel
	<a href="../logout_admin.php" class="btn-login">LOG-OUT</a>
	<a href="../attendance.php" class="btn-login">ATTENDANCE</a>
	<a href="../result.php" class="btn-login">RESULT</a>
	<a href="../home.php" class="btn-login">HOME</a>
	
 </h2>
<script src="ckeditor/ckeditor.js"></script>
<div class="frm">
<form method="post">
<label for="question">Question</label>
<textarea id="editor" name="editor">
</textarea>
<label for="question">Option 1</label>
<textarea id="option1" name="option1">
</textarea>
<label for="question">Option 2</label>
<textarea id="option2" name="option2">
</textarea>
<label for="question">Option 3</label>
<textarea id="option3" name="option3">
</textarea>
<label for="question">Option 4</label>
<textarea id="option4" name="option4">
</textarea>
<label for="question">Correct</label>
<textarea id="correct" name="correct">
</textarea>
<input type="submit" name="submit" value="Upload" class="btn">
</form>
<script>
CKEDITOR.replace('editor',{
      width: '60vw',
      height: 150,
    });
CKEDITOR.replace('option1',{
      width: '60vw',
      height: 150,
    });
CKEDITOR.replace('option2',{
      width: '60vw',
      height: 150,
    });
CKEDITOR.replace('option3',{
      width: '60vw',
      height: 150,
    });
CKEDITOR.replace('option4',{
      width: '60vw',
      height: 150,
    });
CKEDITOR.replace('correct',{
      width: '60vw',
      height: 150,
    });


</script>
</div>
</body>
</html>
<?php
if(isset($_POST['submit'])){
    $question=strip_tags($_POST['editor']);
    $option1=strip_tags($_POST['option1']);
    $option2=strip_tags($_POST['option2']);
    $option3=strip_tags($_POST['option3']);
    $option4=strip_tags($_POST['option4']);
    $correct=strip_tags($_POST['correct']);
    $con=mysqli_connect("localhost","root","","python_exam");
    $sql="insert into questions(question,a,b,c,d,correct,mark)values('$question','$option1','$option2','$option3','$option4','$correct',1)";
    mysqli_query($con,$sql);
}
?>